/* This file is auto generated, version 201505081133 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201505081133 SMP Fri May 8 15:34:52 UTC 2015"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 4.6.3 (Ubuntu/Linaro 4.6.3-1ubuntu5) "
